// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$UserModel {

 String get id; String get name; String get email; String get role;@JsonKey(name: "cover_url") String? get coverUrl;@JsonKey(name: 'creator_user_id') String get creatorUserId;@JsonKey(name: 'created_at') DateTime get createdAt;@JsonKey(name: 'is_active') bool get isActive;@JsonKey(name: 'password_reset_done') bool get passwordResetDone;@JsonKey(name: 'artists_created') int get artistsCreated;@JsonKey(name: 'songs_created') int get songsCreated;
/// Create a copy of UserModel
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$UserModelCopyWith<UserModel> get copyWith => _$UserModelCopyWithImpl<UserModel>(this as UserModel, _$identity);

  /// Serializes this UserModel to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is UserModel&&(identical(other.id, id) || other.id == id)&&(identical(other.name, name) || other.name == name)&&(identical(other.email, email) || other.email == email)&&(identical(other.role, role) || other.role == role)&&(identical(other.coverUrl, coverUrl) || other.coverUrl == coverUrl)&&(identical(other.creatorUserId, creatorUserId) || other.creatorUserId == creatorUserId)&&(identical(other.createdAt, createdAt) || other.createdAt == createdAt)&&(identical(other.isActive, isActive) || other.isActive == isActive)&&(identical(other.passwordResetDone, passwordResetDone) || other.passwordResetDone == passwordResetDone)&&(identical(other.artistsCreated, artistsCreated) || other.artistsCreated == artistsCreated)&&(identical(other.songsCreated, songsCreated) || other.songsCreated == songsCreated));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,id,name,email,role,coverUrl,creatorUserId,createdAt,isActive,passwordResetDone,artistsCreated,songsCreated);

@override
String toString() {
  return 'UserModel(id: $id, name: $name, email: $email, role: $role, coverUrl: $coverUrl, creatorUserId: $creatorUserId, createdAt: $createdAt, isActive: $isActive, passwordResetDone: $passwordResetDone, artistsCreated: $artistsCreated, songsCreated: $songsCreated)';
}


}

/// @nodoc
abstract mixin class $UserModelCopyWith<$Res>  {
  factory $UserModelCopyWith(UserModel value, $Res Function(UserModel) _then) = _$UserModelCopyWithImpl;
@useResult
$Res call({
 String id, String name, String email, String role,@JsonKey(name: "cover_url") String? coverUrl,@JsonKey(name: 'creator_user_id') String creatorUserId,@JsonKey(name: 'created_at') DateTime createdAt,@JsonKey(name: 'is_active') bool isActive,@JsonKey(name: 'password_reset_done') bool passwordResetDone,@JsonKey(name: 'artists_created') int artistsCreated,@JsonKey(name: 'songs_created') int songsCreated
});




}
/// @nodoc
class _$UserModelCopyWithImpl<$Res>
    implements $UserModelCopyWith<$Res> {
  _$UserModelCopyWithImpl(this._self, this._then);

  final UserModel _self;
  final $Res Function(UserModel) _then;

/// Create a copy of UserModel
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,Object? name = null,Object? email = null,Object? role = null,Object? coverUrl = freezed,Object? creatorUserId = null,Object? createdAt = null,Object? isActive = null,Object? passwordResetDone = null,Object? artistsCreated = null,Object? songsCreated = null,}) {
  return _then(_self.copyWith(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,name: null == name ? _self.name : name // ignore: cast_nullable_to_non_nullable
as String,email: null == email ? _self.email : email // ignore: cast_nullable_to_non_nullable
as String,role: null == role ? _self.role : role // ignore: cast_nullable_to_non_nullable
as String,coverUrl: freezed == coverUrl ? _self.coverUrl : coverUrl // ignore: cast_nullable_to_non_nullable
as String?,creatorUserId: null == creatorUserId ? _self.creatorUserId : creatorUserId // ignore: cast_nullable_to_non_nullable
as String,createdAt: null == createdAt ? _self.createdAt : createdAt // ignore: cast_nullable_to_non_nullable
as DateTime,isActive: null == isActive ? _self.isActive : isActive // ignore: cast_nullable_to_non_nullable
as bool,passwordResetDone: null == passwordResetDone ? _self.passwordResetDone : passwordResetDone // ignore: cast_nullable_to_non_nullable
as bool,artistsCreated: null == artistsCreated ? _self.artistsCreated : artistsCreated // ignore: cast_nullable_to_non_nullable
as int,songsCreated: null == songsCreated ? _self.songsCreated : songsCreated // ignore: cast_nullable_to_non_nullable
as int,
  ));
}

}


/// Adds pattern-matching-related methods to [UserModel].
extension UserModelPatterns on UserModel {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _UserModel value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _UserModel() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _UserModel value)  $default,){
final _that = this;
switch (_that) {
case _UserModel():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _UserModel value)?  $default,){
final _that = this;
switch (_that) {
case _UserModel() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String id,  String name,  String email,  String role, @JsonKey(name: "cover_url")  String? coverUrl, @JsonKey(name: 'creator_user_id')  String creatorUserId, @JsonKey(name: 'created_at')  DateTime createdAt, @JsonKey(name: 'is_active')  bool isActive, @JsonKey(name: 'password_reset_done')  bool passwordResetDone, @JsonKey(name: 'artists_created')  int artistsCreated, @JsonKey(name: 'songs_created')  int songsCreated)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _UserModel() when $default != null:
return $default(_that.id,_that.name,_that.email,_that.role,_that.coverUrl,_that.creatorUserId,_that.createdAt,_that.isActive,_that.passwordResetDone,_that.artistsCreated,_that.songsCreated);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String id,  String name,  String email,  String role, @JsonKey(name: "cover_url")  String? coverUrl, @JsonKey(name: 'creator_user_id')  String creatorUserId, @JsonKey(name: 'created_at')  DateTime createdAt, @JsonKey(name: 'is_active')  bool isActive, @JsonKey(name: 'password_reset_done')  bool passwordResetDone, @JsonKey(name: 'artists_created')  int artistsCreated, @JsonKey(name: 'songs_created')  int songsCreated)  $default,) {final _that = this;
switch (_that) {
case _UserModel():
return $default(_that.id,_that.name,_that.email,_that.role,_that.coverUrl,_that.creatorUserId,_that.createdAt,_that.isActive,_that.passwordResetDone,_that.artistsCreated,_that.songsCreated);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String id,  String name,  String email,  String role, @JsonKey(name: "cover_url")  String? coverUrl, @JsonKey(name: 'creator_user_id')  String creatorUserId, @JsonKey(name: 'created_at')  DateTime createdAt, @JsonKey(name: 'is_active')  bool isActive, @JsonKey(name: 'password_reset_done')  bool passwordResetDone, @JsonKey(name: 'artists_created')  int artistsCreated, @JsonKey(name: 'songs_created')  int songsCreated)?  $default,) {final _that = this;
switch (_that) {
case _UserModel() when $default != null:
return $default(_that.id,_that.name,_that.email,_that.role,_that.coverUrl,_that.creatorUserId,_that.createdAt,_that.isActive,_that.passwordResetDone,_that.artistsCreated,_that.songsCreated);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _UserModel implements UserModel {
  const _UserModel({required this.id, required this.name, required this.email, required this.role, @JsonKey(name: "cover_url") this.coverUrl, @JsonKey(name: 'creator_user_id') required this.creatorUserId, @JsonKey(name: 'created_at') required this.createdAt, @JsonKey(name: 'is_active') required this.isActive, @JsonKey(name: 'password_reset_done') required this.passwordResetDone, @JsonKey(name: 'artists_created') this.artistsCreated = 0, @JsonKey(name: 'songs_created') this.songsCreated = 0});
  factory _UserModel.fromJson(Map<String, dynamic> json) => _$UserModelFromJson(json);

@override final  String id;
@override final  String name;
@override final  String email;
@override final  String role;
@override@JsonKey(name: "cover_url") final  String? coverUrl;
@override@JsonKey(name: 'creator_user_id') final  String creatorUserId;
@override@JsonKey(name: 'created_at') final  DateTime createdAt;
@override@JsonKey(name: 'is_active') final  bool isActive;
@override@JsonKey(name: 'password_reset_done') final  bool passwordResetDone;
@override@JsonKey(name: 'artists_created') final  int artistsCreated;
@override@JsonKey(name: 'songs_created') final  int songsCreated;

/// Create a copy of UserModel
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$UserModelCopyWith<_UserModel> get copyWith => __$UserModelCopyWithImpl<_UserModel>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$UserModelToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _UserModel&&(identical(other.id, id) || other.id == id)&&(identical(other.name, name) || other.name == name)&&(identical(other.email, email) || other.email == email)&&(identical(other.role, role) || other.role == role)&&(identical(other.coverUrl, coverUrl) || other.coverUrl == coverUrl)&&(identical(other.creatorUserId, creatorUserId) || other.creatorUserId == creatorUserId)&&(identical(other.createdAt, createdAt) || other.createdAt == createdAt)&&(identical(other.isActive, isActive) || other.isActive == isActive)&&(identical(other.passwordResetDone, passwordResetDone) || other.passwordResetDone == passwordResetDone)&&(identical(other.artistsCreated, artistsCreated) || other.artistsCreated == artistsCreated)&&(identical(other.songsCreated, songsCreated) || other.songsCreated == songsCreated));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,id,name,email,role,coverUrl,creatorUserId,createdAt,isActive,passwordResetDone,artistsCreated,songsCreated);

@override
String toString() {
  return 'UserModel(id: $id, name: $name, email: $email, role: $role, coverUrl: $coverUrl, creatorUserId: $creatorUserId, createdAt: $createdAt, isActive: $isActive, passwordResetDone: $passwordResetDone, artistsCreated: $artistsCreated, songsCreated: $songsCreated)';
}


}

/// @nodoc
abstract mixin class _$UserModelCopyWith<$Res> implements $UserModelCopyWith<$Res> {
  factory _$UserModelCopyWith(_UserModel value, $Res Function(_UserModel) _then) = __$UserModelCopyWithImpl;
@override @useResult
$Res call({
 String id, String name, String email, String role,@JsonKey(name: "cover_url") String? coverUrl,@JsonKey(name: 'creator_user_id') String creatorUserId,@JsonKey(name: 'created_at') DateTime createdAt,@JsonKey(name: 'is_active') bool isActive,@JsonKey(name: 'password_reset_done') bool passwordResetDone,@JsonKey(name: 'artists_created') int artistsCreated,@JsonKey(name: 'songs_created') int songsCreated
});




}
/// @nodoc
class __$UserModelCopyWithImpl<$Res>
    implements _$UserModelCopyWith<$Res> {
  __$UserModelCopyWithImpl(this._self, this._then);

  final _UserModel _self;
  final $Res Function(_UserModel) _then;

/// Create a copy of UserModel
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,Object? name = null,Object? email = null,Object? role = null,Object? coverUrl = freezed,Object? creatorUserId = null,Object? createdAt = null,Object? isActive = null,Object? passwordResetDone = null,Object? artistsCreated = null,Object? songsCreated = null,}) {
  return _then(_UserModel(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,name: null == name ? _self.name : name // ignore: cast_nullable_to_non_nullable
as String,email: null == email ? _self.email : email // ignore: cast_nullable_to_non_nullable
as String,role: null == role ? _self.role : role // ignore: cast_nullable_to_non_nullable
as String,coverUrl: freezed == coverUrl ? _self.coverUrl : coverUrl // ignore: cast_nullable_to_non_nullable
as String?,creatorUserId: null == creatorUserId ? _self.creatorUserId : creatorUserId // ignore: cast_nullable_to_non_nullable
as String,createdAt: null == createdAt ? _self.createdAt : createdAt // ignore: cast_nullable_to_non_nullable
as DateTime,isActive: null == isActive ? _self.isActive : isActive // ignore: cast_nullable_to_non_nullable
as bool,passwordResetDone: null == passwordResetDone ? _self.passwordResetDone : passwordResetDone // ignore: cast_nullable_to_non_nullable
as bool,artistsCreated: null == artistsCreated ? _self.artistsCreated : artistsCreated // ignore: cast_nullable_to_non_nullable
as int,songsCreated: null == songsCreated ? _self.songsCreated : songsCreated // ignore: cast_nullable_to_non_nullable
as int,
  ));
}


}

// dart format on
